#ifndef __OUT_UTILS_H
#define __OUT_UTILS_H

#include "struct.h"

void print_params(FILE *fw);
void print_align(FILE *fw);

#endif
