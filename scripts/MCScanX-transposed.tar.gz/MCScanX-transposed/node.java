public class node
{
public double xpos;
public double ypos;
public node(double x,double y)
{
this.xpos=x;
this.ypos=y;
}
}

