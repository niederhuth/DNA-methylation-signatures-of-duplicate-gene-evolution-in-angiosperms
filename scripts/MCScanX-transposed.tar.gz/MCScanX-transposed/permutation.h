#ifndef __PERMUTATION_H
#define __PERMUTATION_H

#include "struct.h"

double ln_perm(int n, int r);

#endif
